export interface Character {
  id: string;
  user_id: string;
  name: string;
  race: string;
  power_level: number;
  alignment: 'Hero' | 'Villain' | 'Anti-Hero' | 'Neutral';
  status: 'Alive' | 'Deceased' | 'Unknown' | 'Missing';
  creator: string;
  current_location?: string;
  personality?: string;
  backstory?: string;
  appearance?: string;
  extra_notes?: string;
  approved: boolean;
  reviewed_by?: string;
  reviewed_at?: string;
  rejection_reason?: string;
  admin_notes?: string;
  created_at: string;
  updated_at: string;
  techniques?: Technique[];
  abilities?: Ability[];
}

export interface Technique {
  id: string;
  character_id: string;
  name: string;
  description: string;
  type: string;
  created_at: string;
}

export interface Ability {
  id: string;
  character_id: string;
  name: string;
  description: string;
  created_at: string;
}

export interface Profile {
  id: string;
  user_id: string;
  display_name?: string;
  avatar_url?: string;
  bio?: string;
  created_at: string;
  updated_at: string;
}