import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Shield, 
  Users, 
  CheckCircle, 
  XCircle, 
  Eye,
  Edit,
  Trash2,
  Crown
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useAdmin } from '@/hooks/useAdmin';
import { useToast } from '@/hooks/use-toast';
import { Character } from '@/types/database';

const Admin = () => {
  const { user } = useAuth();
  const { isAdmin, loading: adminLoading } = useAdmin();
  const { toast } = useToast();
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const [rejectionReason, setRejectionReason] = useState('');
  const [adminNotes, setAdminNotes] = useState('');

  useEffect(() => {
    if (isAdmin) {
      fetchPendingCharacters();
    }
  }, [isAdmin]);

  const fetchPendingCharacters = async () => {
    try {
      const { data, error } = await supabase
        .from('characters')
        .select(`
          *,
          techniques (*),
          abilities (*)
        `)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      
      // Type cast to handle the extended Character interface
      setCharacters((data || []) as Character[]);
    } catch (error) {
      console.error('Error fetching characters:', error);
      toast({
        title: "Error",
        description: "Failed to fetch characters",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (characterId: string) => {
    try {
      const { error } = await supabase
        .from('characters')
        .update({
          approved: true,
          reviewed_by: user?.id,
          reviewed_at: new Date().toISOString(),
          admin_notes: adminNotes
        })
        .eq('id', characterId);
      
      if (error) throw error;
      
      toast({
        title: "Character Approved",
        description: "The character has been approved and is now visible to all users.",
      });
      
      fetchPendingCharacters();
    } catch (error) {
      console.error('Error approving character:', error);
      toast({
        title: "Error",
        description: "Failed to approve character",
        variant: "destructive"
      });
    }
  };

  const handleReject = async (characterId: string) => {
    if (!rejectionReason.trim()) {
      toast({
        title: "Rejection Reason Required",
        description: "Please provide a reason for rejection",
        variant: "destructive"
      });
      return;
    }

    try {
      const { error } = await supabase
        .from('characters')
        .update({
          approved: false,
          reviewed_by: user?.id,
          reviewed_at: new Date().toISOString(),
          rejection_reason: rejectionReason,
          admin_notes: adminNotes
        })
        .eq('id', characterId);
      
      if (error) throw error;
      
      toast({
        title: "Character Rejected",
        description: "The character has been rejected with the provided reason.",
      });
      
      fetchPendingCharacters();
      setRejectionReason('');
    } catch (error) {
      console.error('Error rejecting character:', error);
      toast({
        title: "Error",
        description: "Failed to reject character",
        variant: "destructive"
      });
    }
  };

  const handleDelete = async (characterId: string) => {
    try {
      const { error } = await supabase
        .from('characters')
        .delete()
        .eq('id', characterId);
      
      if (error) throw error;
      
      toast({
        title: "Character Deleted",
        description: "The character has been permanently deleted.",
      });
      
      fetchPendingCharacters();
    } catch (error) {
      console.error('Error deleting character:', error);
      toast({
        title: "Error",
        description: "Failed to delete character",
        variant: "destructive"
      });
    }
  };

  if (adminLoading || loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="text-center py-12">
        <Shield className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
        <h2 className="text-2xl font-bold mb-2">Access Denied</h2>
        <p className="text-muted-foreground">
          You don't have permission to access the admin panel.
        </p>
      </div>
    );
  }

  const pendingCharacters = characters.filter(c => !c.approved && !c.rejection_reason);
  const approvedCharacters = characters.filter(c => c.approved);
  const rejectedCharacters = characters.filter(c => c.rejection_reason);

  return (
    <div className="space-y-8">
      <div className="flex items-center gap-4">
        <div className="w-12 h-12 bg-gradient-to-br from-primary to-energy rounded-full flex items-center justify-center">
          <Crown className="w-6 h-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-energy bg-clip-text text-transparent">
            Admin Panel
          </h1>
          <p className="text-muted-foreground">Manage character submissions and site content</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pending</p>
                <p className="text-2xl font-bold text-energy">{pendingCharacters.length}</p>
              </div>
              <Eye className="w-8 h-8 text-energy" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Approved</p>
                <p className="text-2xl font-bold text-ki">{approvedCharacters.length}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-ki" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Rejected</p>
                <p className="text-2xl font-bold text-destructive">{rejectedCharacters.length}</p>
              </div>
              <XCircle className="w-8 h-8 text-destructive" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total</p>
                <p className="text-2xl font-bold">{characters.length}</p>
              </div>
              <Users className="w-8 h-8 text-primary" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Characters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-energy" />
            Pending Approval ({pendingCharacters.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {pendingCharacters.length === 0 ? (
            <p className="text-muted-foreground text-center py-8">No pending characters</p>
          ) : (
            <div className="space-y-4">
              {pendingCharacters.map((character) => (
                <div key={character.id} className="p-4 border border-border rounded-lg">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">{character.name}</h3>
                      <p className="text-muted-foreground">
                        {character.race} • Power Level: {character.power_level?.toLocaleString()}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        Created by: {character.creator} • {new Date(character.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge variant="secondary">{character.alignment}</Badge>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <h4 className="font-medium mb-2">Backstory</h4>
                      <p className="text-sm text-muted-foreground">{character.backstory}</p>
                    </div>
                    <div>
                      <h4 className="font-medium mb-2">Personality</h4>
                      <p className="text-sm text-muted-foreground">{character.personality}</p>
                    </div>
                  </div>

                  {character.techniques && character.techniques.length > 0 && (
                    <div className="mb-4">
                      <h4 className="font-medium mb-2">Techniques</h4>
                      <div className="space-y-2">
                        {character.techniques.map((technique) => (
                          <div key={technique.id} className="p-2 bg-muted/30 rounded">
                            <div className="flex items-center gap-2">
                              <span className="font-medium text-sm">{technique.name}</span>
                              <Badge variant="outline" className="text-xs">{technique.type}</Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">{technique.description}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="text-sm font-medium block mb-2">Rejection Reason</label>
                      <Textarea
                        placeholder="Provide reason for rejection (optional)"
                        value={selectedCharacter?.id === character.id ? rejectionReason : ''}
                        onChange={(e) => {
                          setRejectionReason(e.target.value);
                          setSelectedCharacter(character);
                        }}
                        className="text-sm"
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium block mb-2">Admin Notes</label>
                      <Textarea
                        placeholder="Internal notes (optional)"
                        value={selectedCharacter?.id === character.id ? adminNotes : ''}
                        onChange={(e) => {
                          setAdminNotes(e.target.value);
                          setSelectedCharacter(character);
                        }}
                        className="text-sm"
                      />
                    </div>
                  </div>
                  
                  <div className="flex gap-2">
                    <Button
                      onClick={() => handleApprove(character.id)}
                      className="bg-ki hover:bg-ki/90 text-ki-foreground"
                    >
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Approve
                    </Button>
                    <Button
                      onClick={() => handleReject(character.id)}
                      variant="destructive"
                    >
                      <XCircle className="w-4 h-4 mr-2" />
                      Reject
                    </Button>
                    <Button
                      onClick={() => handleDelete(character.id)}
                      variant="outline"
                      className="border-destructive text-destructive hover:bg-destructive hover:text-destructive-foreground"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Admin;