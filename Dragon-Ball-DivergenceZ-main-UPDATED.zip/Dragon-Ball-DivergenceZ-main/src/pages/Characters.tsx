import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { 
  Search, 
  Filter, 
  Zap, 
  Users, 
  Star,
  Crown,
  Swords,
  Eye,
  Heart,
  Skull,
  Shield,
  Loader2
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { Character } from '@/types/database';
import { useToast } from '@/hooks/use-toast';

const Characters = () => {
  const [characters, setCharacters] = useState<Character[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [raceFilter, setRaceFilter] = useState('all');
  const [alignmentFilter, setAlignmentFilter] = useState('all');
  const [selectedCharacter, setSelectedCharacter] = useState<Character | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    fetchCharacters();
  }, []);

  const fetchCharacters = async () => {
    try {
      const { data, error } = await supabase
        .from('characters')
        .select(`
          *,
          techniques(*),
          abilities(*)
        `)
        .eq('approved', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setCharacters((data || []) as Character[]);
    } catch (error) {
      console.error('Error fetching characters:', error);
      toast({
        title: "Error",
        description: "Failed to load characters",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  const filteredCharacters = characters.filter(character => {
    const matchesSearch = character.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         character.creator.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRace = raceFilter === 'all' || character.race === raceFilter;
    const matchesAlignment = alignmentFilter === 'all' || character.alignment === alignmentFilter;
    
    return matchesSearch && matchesRace && matchesAlignment;
  });

  const getAlignmentColor = (alignment: string) => {
    switch (alignment) {
      case 'Hero': return 'bg-secondary text-secondary-foreground';
      case 'Villain': return 'bg-destructive text-destructive-foreground';
      case 'Anti-Hero': return 'bg-accent text-accent-foreground';
      case 'Neutral': return 'bg-muted text-muted-foreground';
      default: return 'bg-muted text-muted-foreground';
    }
  };

  const getAlignmentIcon = (alignment: string) => {
    switch (alignment) {
      case 'Hero': return <Heart className="w-3 h-3" />;
      case 'Villain': return <Skull className="w-3 h-3" />;
      case 'Anti-Hero': return <Shield className="w-3 h-3" />;
      case 'Neutral': return <Star className="w-3 h-3" />;
      default: return <Star className="w-3 h-3" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Alive': return 'text-secondary bg-secondary/10 border-secondary/20';
      case 'Deceased': return 'text-destructive bg-destructive/10 border-destructive/20';
      case 'Missing': return 'text-yellow-500 bg-yellow-500/10 border-yellow-500/20';
      case 'Unknown': return 'text-muted-foreground bg-muted/10 border-muted/20';
      default: return 'text-muted-foreground bg-muted/10 border-muted/20';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Alive': return <Heart className="w-3 h-3 mr-1" />;
      case 'Deceased': return <Skull className="w-3 h-3 mr-1" />;
      default: return null;
    }
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="text-center">
          <h1 className="text-3xl font-bold mb-2">Loading Characters...</h1>
          <Loader2 className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto" />
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar */}
        <div className="lg:w-80 space-y-6">
          <Card className="bg-gradient-to-br from-card to-card/50">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Filter className="w-5 h-5 text-primary" />
                Filters
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Search Characters</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search by name or creator..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Race</label>
                <Select value={raceFilter} onValueChange={setRaceFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Races</SelectItem>
                    <SelectItem value="Saiyan">Saiyan</SelectItem>
                    <SelectItem value="Human">Human</SelectItem>
                    <SelectItem value="Namekian">Namekian</SelectItem>
                    <SelectItem value="Majin">Majin</SelectItem>
                    <SelectItem value="Android">Android</SelectItem>
                    <SelectItem value="Frieza Race">Frieza Race</SelectItem>
                    <SelectItem value="Custom">Custom</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Alignment</label>
                <Select value={alignmentFilter} onValueChange={setAlignmentFilter}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Alignments</SelectItem>
                    <SelectItem value="Hero">Heroes</SelectItem>
                    <SelectItem value="Villain">Villains</SelectItem>
                    <SelectItem value="Anti-Hero">Anti-Heroes</SelectItem>
                    <SelectItem value="Neutral">Neutral</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-primary/10 to-energy/5 border-primary/20">
            <CardHeader>
              <CardTitle className="text-lg">Universe Statistics</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between">
                <span className="text-sm">Total Characters</span>
                <span className="font-bold text-primary">{characters.length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Heroes</span>
                <span className="font-bold text-secondary">{characters.filter(c => c.alignment === 'Hero').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Villains</span>
                <span className="font-bold text-destructive">{characters.filter(c => c.alignment === 'Villain').length}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm">Active Characters</span>
                <span className="font-bold text-accent">{characters.filter(c => c.status === 'Alive').length}</span>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Characters Grid */}
        <div className="flex-1">
          <div className="mb-6">
            <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-energy bg-clip-text text-transparent mb-2">
              Character Database
            </h1>
            <p className="text-muted-foreground">
              Discover the legendary warriors shaping the destiny of the universe
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredCharacters.map((character) => (
              <Card 
                key={character.id} 
                className="bg-gradient-to-br from-card to-card/50 border-border/50 hover:border-primary/20 transition-all duration-300 cursor-pointer animate-fade-in"
                onClick={() => setSelectedCharacter(character)}
              >
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="flex items-center gap-2 text-lg">
                        {character.creator === 'Admin' && (
                          <Crown className="w-4 h-4 text-ki" />
                        )}
                        {character.name}
                      </CardTitle>
                      <CardDescription className="flex items-center gap-2 mt-1">
                        <Users className="w-3 h-3" />
                        {character.race}
                      </CardDescription>
                    </div>
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${getStatusColor(character.status)}`}
                    >
                      {character.status}
                    </Badge>
                  </div>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <Badge variant="outline" className="mb-2">
                    Power Level: {character.power_level.toLocaleString()}
                  </Badge>
                  <div className="flex flex-wrap gap-2 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {character.race}
                    </div>
                    <div className="flex items-center gap-1">
                      {getAlignmentIcon(character.alignment)}
                      {character.alignment}
                    </div>
                    {character.current_location && (
                      <div className="text-xs">
                        📍 {character.current_location}
                      </div>
                    )}
                  </div>
                  <p className="text-xs text-muted-foreground mt-2">
                    Created by: <span className="font-medium">{character.creator}</span>
                  </p>

                  <Button 
                    variant="ghost" 
                    size="sm" 
                    className="w-full mt-4 hover:bg-primary/10"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedCharacter(character);
                    }}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    View Details
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredCharacters.length === 0 && (
            <Card className="bg-gradient-to-br from-card to-card/50 border-border/50">
              <CardContent className="text-center py-12">
                <Swords className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Characters Found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search criteria or filters
                </p>
                <Button variant="outline" onClick={() => {
                  setSearchTerm('');
                  setRaceFilter('all');
                  setAlignmentFilter('all');
                }}>
                  Clear Filters
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Character Detail Dialog */}
      <Dialog open={!!selectedCharacter} onOpenChange={() => setSelectedCharacter(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-2xl">
              {selectedCharacter?.creator === 'Admin' && (
                <Crown className="w-5 h-5 text-ki" />
              )}
              {selectedCharacter?.name}
            </DialogTitle>
            <DialogDescription className="text-lg">
              {selectedCharacter?.race} • {selectedCharacter?.alignment}
            </DialogDescription>
          </DialogHeader>
          
          {selectedCharacter && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-sm mb-1">Power Level</h4>
                  <Badge variant="outline" className="w-full justify-center">
                    <Zap className="w-3 h-3 mr-1" />
                    {selectedCharacter.power_level.toLocaleString()}
                  </Badge>
                </div>
                <div>
                  <h4 className="font-medium text-sm mb-1">Status</h4>
                  <Badge 
                    variant="outline" 
                    className={`w-full justify-center ${getStatusColor(selectedCharacter.status)}`}
                  >
                    {getStatusIcon(selectedCharacter.status)}
                    {selectedCharacter.status}
                  </Badge>
                </div>
              </div>

              {selectedCharacter.current_location && (
                <div>
                  <h4 className="font-medium text-sm mb-1">Current Location</h4>
                  <p className="text-sm text-muted-foreground">📍 {selectedCharacter.current_location}</p>
                </div>
              )}

              {selectedCharacter.personality && (
                <div>
                  <h4 className="font-medium text-sm mb-1">Personality</h4>
                  <p className="text-sm text-muted-foreground">{selectedCharacter.personality}</p>
                </div>
              )}

              {selectedCharacter.backstory && (
                <div>
                  <h4 className="font-medium text-sm mb-1">Backstory</h4>
                  <p className="text-sm text-muted-foreground">{selectedCharacter.backstory}</p>
                </div>
              )}

              {selectedCharacter.appearance && (
                <div>
                  <h4 className="font-medium text-sm mb-1">Appearance</h4>
                  <p className="text-sm text-muted-foreground">{selectedCharacter.appearance}</p>
                </div>
              )}

              {selectedCharacter.techniques && selectedCharacter.techniques.length > 0 && (
                <div>
                  <h4 className="font-medium text-sm mb-2">Techniques</h4>
                  <div className="space-y-2">
                    {selectedCharacter.techniques.map((technique) => (
                      <div key={technique.id} className="p-2 bg-muted rounded-md">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-sm">{technique.name}</span>
                          <Badge variant="secondary" className="text-xs">{technique.type}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">{technique.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedCharacter.abilities && selectedCharacter.abilities.length > 0 && (
                <div>
                  <h4 className="font-medium text-sm mb-2">Abilities</h4>
                  <div className="space-y-2">
                    {selectedCharacter.abilities.map((ability) => (
                      <div key={ability.id} className="p-2 bg-muted rounded-md">
                        <span className="font-medium text-sm">{ability.name}</span>
                        <p className="text-xs text-muted-foreground mt-1">{ability.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {selectedCharacter.extra_notes && (
                <div>
                  <h4 className="font-medium text-sm mb-1">Additional Notes</h4>
                  <p className="text-sm text-muted-foreground">{selectedCharacter.extra_notes}</p>
                </div>
              )}

              <div className="text-center pt-4 border-t">
                <p className="text-xs text-muted-foreground">
                  Created by <span className="font-medium">{selectedCharacter.creator}</span> on{' '}
                  {new Date(selectedCharacter.created_at).toLocaleDateString()}
                </p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Characters;