import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { 
  Users, 
  Zap, 
  Globe, 
  Clock, 
  FileText, 
  Star,
  ArrowRight,
  Shield,
  Sword
} from "lucide-react";

const Index = () => {
  const { user } = useAuth();

  const features = [
    {
      icon: Users,
      title: "Character Creation",
      description: "Design legendary fighters with unique abilities and backstories",
      color: "text-secondary"
    },
    {
      icon: Clock,
      title: "Epic Timeline",
      description: "Follow the universe's greatest sagas and battles",
      color: "text-accent"
    },
    {
      icon: Globe,
      title: "Universe Explorer",
      description: "Visit planets and dimensions across the multiverse",
      color: "text-energy"
    },
    {
      icon: Zap,
      title: "Power Management",
      description: "Track transformations and power level progression",
      color: "text-ki"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted/20">
      {/* Hero Section */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/5 via-energy/5 to-ki/5" />
        <div className="relative max-w-7xl mx-auto px-4 py-20 sm:py-32">
          <div className="text-center space-y-8">
            <div className="animate-fade-in">
              <Badge className="mb-4 bg-gradient-to-r from-primary to-energy text-primary-foreground">
                <Star className="w-3 h-3 mr-1" />
                Multiverse RPG Hub
              </Badge>
              <h1 className="text-5xl sm:text-7xl font-bold bg-gradient-to-r from-primary via-energy to-ki bg-clip-text text-transparent mb-6">
                Dragon Ball Universe
              </h1>
              <p className="text-xl sm:text-2xl text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                Create legendary warriors, explore infinite universes, and shape the destiny of the multiverse. 
                Your epic journey begins here among the stars!
              </p>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mt-12">
              {user ? (
                <>
                  <Link to="/home">
                    <Button size="lg" className="bg-gradient-to-r from-primary to-energy text-primary-foreground hover:scale-105 transition-transform">
                      <Shield className="w-5 h-5 mr-2" />
                      Enter Universe
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                  <Link to="/characters">
                    <Button size="lg" variant="outline" className="border-primary/30 hover:bg-primary/10">
                      <Users className="w-5 h-5 mr-2" />
                      View Characters
                    </Button>
                  </Link>
                </>
              ) : (
                <>
                  <Link to="/auth">
                    <Button size="lg" className="bg-gradient-to-r from-primary to-energy text-primary-foreground hover:scale-105 transition-transform">
                      <Sword className="w-5 h-5 mr-2" />
                      Begin Your Journey
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                  <Link to="/characters">
                    <Button size="lg" variant="outline" className="border-primary/30 hover:bg-primary/10">
                      <Users className="w-5 h-5 mr-2" />
                      Explore Characters
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Features Section */}
      <div className="max-w-7xl mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold mb-4">
            Unleash Your <span className="bg-gradient-to-r from-primary to-ki bg-clip-text text-transparent">Inner Warrior</span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Experience the ultimate Dragon Ball RPG with comprehensive character management and universe exploration
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => (
            <Card 
              key={feature.title} 
              className="bg-gradient-to-br from-card to-card/50 border-border/50 hover:border-primary/20 transition-all duration-300 hover:scale-105 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 p-3 rounded-full bg-gradient-to-br from-primary/10 to-energy/10 w-fit">
                  <feature.icon className={`w-8 h-8 ${feature.color}`} />
                </div>
                <CardTitle className="text-xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-center leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Stats Section */}
      <div className="bg-gradient-to-r from-primary/5 via-energy/5 to-ki/5 py-20">
        <div className="max-w-6xl mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div className="space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-primary to-energy bg-clip-text text-transparent">12</div>
              <div className="text-muted-foreground">Universes</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-secondary to-accent bg-clip-text text-transparent">∞</div>
              <div className="text-muted-foreground">Power Levels</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-energy to-ki bg-clip-text text-transparent">47+</div>
              <div className="text-muted-foreground">Characters</div>
            </div>
            <div className="space-y-2">
              <div className="text-4xl font-bold bg-gradient-to-r from-ki to-primary bg-clip-text text-transparent">23</div>
              <div className="text-muted-foreground">Epic Sagas</div>
            </div>
          </div>
        </div>
      </div>

      {/* Call to Action */}
      <div className="max-w-4xl mx-auto px-4 py-20 text-center">
        <Card className="bg-gradient-to-r from-primary/10 via-energy/5 to-ki/10 border-primary/20">
          <CardHeader>
            <CardTitle className="text-3xl">Ready to Ascend?</CardTitle>
            <CardDescription className="text-lg mt-4">
              Join the legendary warriors and begin your transformation into the ultimate fighter
            </CardDescription>
          </CardHeader>
          <CardContent className="pt-6">
            {user ? (
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link to="/submit-oc">
                  <Button size="lg" className="bg-gradient-to-r from-primary to-energy">
                    <FileText className="w-5 h-5 mr-2" />
                    Create Your Character
                  </Button>
                </Link>
                <Link to="/timeline">
                  <Button size="lg" variant="outline" className="border-primary/30">
                    <Clock className="w-5 h-5 mr-2" />
                    Explore Timeline
                  </Button>
                </Link>
              </div>
            ) : (
              <Link to="/auth">
                <Button size="lg" className="bg-gradient-to-r from-primary to-energy">
                  <Star className="w-5 h-5 mr-2" />
                  Start Your Legend
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </Link>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Index;
