import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, 
  Star, 
  Users, 
  Scroll,
  Zap,
  Eye,
  Crown
} from "lucide-react";

interface TimelineEvent {
  id: string;
  title: string;
  period: string;
  description: string;
  isCurrentArc: boolean;
  majorCharacters: string[];
  image?: string;
  details: {
    summary: string;
    keyEvents: string[];
    outcome: string;
    powerLevelsAchieved: string[];
  };
}

// Mock timeline data - would come from Supabase
const mockTimeline: TimelineEvent[] = [
  {
    id: "1",
    title: "Saiyan Saga",
    period: "Age 761",
    description: "The arrival of Raditz reveals Goku's true heritage as a Saiyan warrior.",
    isCurrentArc: false,
    majorCharacters: ["Goku", "Vegeta", "Piccolo", "Gohan"],
    details: {
      summary: "The saga that introduced the concept of power levels and transformed the series forever.",
      keyEvents: [
        "Raditz arrives on Earth",
        "Goku sacrifices himself",
        "Vegeta and Nappa invasion",
        "First Super Saiyan transformation foreshadowed"
      ],
      outcome: "Earth defended, Goku and Vegeta begin their rivalry",
      powerLevelsAchieved: ["Goku: 8,000+", "Vegeta: 18,000", "Piccolo: 3,500"]
    }
  },
  {
    id: "2", 
    title: "Frieza Saga",
    period: "Age 762",
    description: "The legendary Super Saiyan awakens on the dying planet Namek.",
    isCurrentArc: false,
    majorCharacters: ["Goku", "Vegeta", "Frieza", "Gohan", "Piccolo"],
    details: {
      summary: "The battle against the universe's most feared tyrant reaches its climax on Namek.",
      keyEvents: [
        "Journey to Namek",
        "Ginyu Force battles",
        "Frieza's transformations",
        "First Super Saiyan transformation"
      ],
      outcome: "Frieza defeated, Super Saiyan legend fulfilled",
      powerLevelsAchieved: ["Super Saiyan Goku: 150,000,000", "Final Form Frieza: 120,000,000"]
    }
  },
  {
    id: "3",
    title: "Tournament of Power",
    period: "Age 780",
    description: "80 fighters from 8 universes battle for survival in the ultimate tournament.",
    isCurrentArc: true,
    majorCharacters: ["Goku", "Vegeta", "Frieza", "Jiren", "Hit"],
    details: {
      summary: "The multiverse's greatest warriors compete with universe-ending stakes.",
      keyEvents: [
        "Universe 7 team formation",
        "Ultra Instinct awakening",
        "Vegeta's new form",
        "Final battle against Jiren"
      ],
      outcome: "Ongoing - Universe 7 fighting for survival",
      powerLevelsAchieved: ["Ultra Instinct Goku: Immeasurable", "Limit Breaker Jiren: Immeasurable"]
    }
  }
];

const Timeline = () => {
  const [selectedEvent, setSelectedEvent] = useState<TimelineEvent | null>(null);
  const [hoveredEvent, setHoveredEvent] = useState<string | null>(null);

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-energy to-ki bg-clip-text text-transparent">
          Universal Timeline
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Journey through the epic saga of battles, transformations, and legendary moments that shaped the universe
        </p>
      </div>

      {/* Timeline Visualization */}
      <div className="relative max-w-6xl mx-auto">
        {/* Timeline Line */}
        <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-gradient-to-b from-primary via-energy to-ki rounded-full opacity-60" />
        
        {/* Timeline Events */}
        <div className="space-y-16">
          {mockTimeline.map((event, index) => (
            <div 
              key={event.id}
              className={`relative flex items-center ${
                index % 2 === 0 ? 'flex-row' : 'flex-row-reverse'
              }`}
              onMouseEnter={() => setHoveredEvent(event.id)}
              onMouseLeave={() => setHoveredEvent(null)}
            >
              {/* Event Card */}
              <div className={`w-5/12 ${index % 2 === 0 ? 'pr-8' : 'pl-8'}`}>
                <Card 
                  className={`bg-gradient-to-br from-card to-card/50 border-border/50 hover:border-primary/30 transition-all duration-300 cursor-pointer transform hover:scale-105 ${
                    event.isCurrentArc ? 'animate-ki-pulse border-ki/50' : ''
                  } ${
                    hoveredEvent === event.id ? 'shadow-lg shadow-primary/20' : ''
                  }`}
                  onClick={() => setSelectedEvent(event)}
                >
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="flex items-center gap-2">
                          {event.isCurrentArc && (
                            <Star className="w-4 h-4 text-ki animate-pulse" />
                          )}
                          {event.title}
                        </CardTitle>
                        <CardDescription className="text-primary font-semibold">
                          {event.period}
                        </CardDescription>
                      </div>
                      {event.isCurrentArc && (
                        <Badge className="bg-gradient-to-r from-ki to-energy text-background animate-pulse">
                          Current Arc
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">
                      {event.description}
                    </p>
                    
                    <div className="space-y-2">
                      <span className="text-xs text-muted-foreground">Major Characters:</span>
                      <div className="flex flex-wrap gap-1">
                        {event.majorCharacters.slice(0, 3).map((character) => (
                          <Badge key={character} variant="outline" className="text-xs">
                            {character}
                          </Badge>
                        ))}
                        {event.majorCharacters.length > 3 && (
                          <Badge variant="outline" className="text-xs">
                            +{event.majorCharacters.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>

                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="w-full mt-4 hover:bg-primary/10"
                    >
                      <Eye className="w-4 h-4 mr-2" />
                      View Details
                    </Button>
                  </CardContent>
                </Card>
              </div>

              {/* Timeline Node */}
              <div className="absolute left-1/2 transform -translate-x-1/2 z-10">
                <div className={`w-6 h-6 rounded-full border-4 transition-all duration-300 ${
                  event.isCurrentArc 
                    ? 'bg-ki border-background animate-ki-pulse' 
                    : hoveredEvent === event.id
                    ? 'bg-primary border-background shadow-lg shadow-primary/50'
                    : 'bg-card border-primary/20'
                }`}>
                  <div className={`w-full h-full rounded-full ${
                    event.isCurrentArc ? 'bg-ki/50 animate-pulse' : 'bg-primary/20'
                  }`} />
                </div>
              </div>

              {/* Spacer */}
              <div className="w-5/12" />
            </div>
          ))}
        </div>
      </div>

      {/* Current Arc Highlight */}
      <Card className="bg-gradient-to-r from-primary/10 via-energy/5 to-ki/10 border-ki/20 max-w-4xl mx-auto">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl flex items-center justify-center gap-2">
            <Star className="w-6 h-6 text-ki" />
            Current Arc: Tournament of Power
          </CardTitle>
          <CardDescription className="text-base">
            The fate of Universe 7 hangs in the balance as our heroes face their ultimate challenge
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="space-y-2">
              <div className="text-2xl font-bold text-ki">48</div>
              <div className="text-sm text-muted-foreground">Minutes Remaining</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-energy">8</div>
              <div className="text-sm text-muted-foreground">Universes Competing</div>
            </div>
            <div className="space-y-2">
              <div className="text-2xl font-bold text-primary">23</div>
              <div className="text-sm text-muted-foreground">Fighters Remaining</div>
            </div>
          </div>
          <Button className="bg-gradient-to-r from-primary to-energy">
            <Users className="w-4 h-4 mr-2" />
            View Active Fighters
          </Button>
        </CardContent>
      </Card>

      {/* Event Detail Modal */}
      {selectedEvent && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedEvent(null)}
        >
          <Card 
            className="bg-gradient-to-br from-card to-card/50 border-primary/20 max-w-4xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-3xl flex items-center gap-3">
                    {selectedEvent.isCurrentArc && (
                      <Star className="w-6 h-6 text-ki animate-pulse" />
                    )}
                    {selectedEvent.title}
                  </CardTitle>
                  <CardDescription className="text-xl text-primary mt-2">
                    {selectedEvent.period}
                  </CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setSelectedEvent(null)}>
                  ×
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Scroll className="w-5 h-5 text-accent" />
                  Arc Summary
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {selectedEvent.details.summary}
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Clock className="w-5 h-5 text-energy" />
                  Key Events
                </h3>
                <div className="space-y-3">
                  {selectedEvent.details.keyEvents.map((event, index) => (
                    <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/20">
                      <div className="w-2 h-2 rounded-full bg-primary mt-2 flex-shrink-0" />
                      <span className="text-foreground">{event}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <Users className="w-5 h-5 text-secondary" />
                    Major Characters
                  </h3>
                  <div className="flex flex-wrap gap-2">
                    {selectedEvent.majorCharacters.map((character) => (
                      <Badge key={character} variant="outline" className="bg-secondary/10 border-secondary/20 text-secondary">
                        {character}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                    <Zap className="w-5 h-5 text-ki" />
                    Power Levels Achieved
                  </h3>
                  <div className="space-y-2">
                    {selectedEvent.details.powerLevelsAchieved.map((level, index) => (
                      <div key={index} className="text-sm font-mono text-muted-foreground">
                        {level}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Crown className="w-5 h-5 text-primary" />
                  Outcome
                </h3>
                <p className="text-muted-foreground leading-relaxed p-4 rounded-lg bg-primary/5 border border-primary/20">
                  {selectedEvent.details.outcome}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Timeline;