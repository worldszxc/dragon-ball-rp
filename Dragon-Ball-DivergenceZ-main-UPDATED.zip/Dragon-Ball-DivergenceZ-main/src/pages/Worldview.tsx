import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Globe, 
  Users, 
  Star, 
  MapPin,
  Zap,
  Crown,
  Eye,
  Mountain
} from "lucide-react";

interface Location {
  id: string;
  name: string;
  type: "planet" | "dimension" | "sacred" | "space";
  description: string;
  currentCharacters: string[];
  significance: string;
  powerLevel?: string;
}

interface Universe {
  id: string;
  name: string;
  mortalLevel: number;
  god: string;
  angel: string;
  locations: Location[];
}

// Mock cosmology data - would come from Supabase
const universes: Universe[] = [
  {
    id: "7",
    name: "Universe 7",
    mortalLevel: 3.18,
    god: "Beerus",
    angel: "Whis",
    locations: [
      {
        id: "earth",
        name: "Earth",
        type: "planet",
        description: "The home planet of humanity and many Z-fighters. A blue world with diverse climates and the birthplace of numerous legendary warriors.",
        currentCharacters: ["Goku", "Vegeta", "Gohan", "Piccolo", "Krillin"],
        significance: "Primary setting for most Dragon Ball adventures",
        powerLevel: "Low-Mid Class"
      },
      {
        id: "namek",
        name: "Namek",
        type: "planet", 
        description: "The peaceful homeworld of the Namekians, known for its three suns and eternal daylight. Destroyed and later restored.",
        currentCharacters: ["Dende", "Nail", "Guru"],
        significance: "Source of the original Dragon Balls",
        powerLevel: "Mid Class"
      },
      {
        id: "kais-planet",
        name: "Supreme Kai's Planet",
        type: "sacred",
        description: "The sacred realm where the Supreme Kai resides, featuring the legendary Z-Sword and mystical training grounds.",
        currentCharacters: ["Supreme Kai", "Kibito"],
        significance: "Supreme deity residence and training ground",
        powerLevel: "Divine Class"
      }
    ]
  },
  {
    id: "6", 
    name: "Universe 6",
    mortalLevel: 4.32,
    god: "Champa",
    angel: "Vados",
    locations: [
      {
        id: "sadala",
        name: "Planet Sadala",
        type: "planet",
        description: "The Saiyan homeworld in Universe 6, still thriving with a peaceful Saiyan civilization unlike Universe 7's destroyed Planet Vegeta.",
        currentCharacters: ["Cabba", "Caulifla", "Kale"],
        significance: "Home of the good Saiyans",
        powerLevel: "High Class"
      }
    ]
  }
];

const Worldview = () => {
  const [selectedUniverse, setSelectedUniverse] = useState<Universe>(universes[0]);
  const [selectedLocation, setSelectedLocation] = useState<Location | null>(null);

  const getLocationIcon = (type: string) => {
    switch (type) {
      case "planet": return Globe;
      case "sacred": return Star;
      case "dimension": return Zap;
      case "space": return Mountain;
      default: return MapPin;
    }
  };

  const getLocationColor = (type: string) => {
    switch (type) {
      case "planet": return "text-secondary";
      case "sacred": return "text-ki";
      case "dimension": return "text-energy";
      case "space": return "text-primary";
      default: return "text-muted-foreground";
    }
  };

  return (
    <div className="space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-energy to-ki bg-clip-text text-transparent">
          Universal Cosmology
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Explore the infinite multiverse and discover where legendary warriors call home
        </p>
      </div>

      {/* Universe Selection */}
      <div className="max-w-4xl mx-auto">
        <Tabs value={selectedUniverse.id} onValueChange={(value) => {
          const universe = universes.find(u => u.id === value);
          if (universe) setSelectedUniverse(universe);
        }}>
          <TabsList className="grid w-full grid-cols-2">
            {universes.map((universe) => (
              <TabsTrigger key={universe.id} value={universe.id} className="text-sm">
                {universe.name}
              </TabsTrigger>
            ))}
          </TabsList>

          {universes.map((universe) => (
            <TabsContent key={universe.id} value={universe.id} className="mt-8">
              {/* Universe Info */}
              <Card className="bg-gradient-to-r from-primary/10 via-energy/5 to-ki/10 border-primary/20 mb-8">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-2xl flex items-center gap-2">
                        <Star className="w-6 h-6 text-ki" />
                        {universe.name}
                      </CardTitle>
                      <CardDescription className="text-base mt-2">
                        Governed by {universe.god} and guided by {universe.angel}
                      </CardDescription>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-primary">{universe.mortalLevel}</div>
                      <div className="text-sm text-muted-foreground">Mortal Level</div>
                    </div>
                  </div>
                </CardHeader>
              </Card>

              {/* Locations Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {universe.locations.map((location) => {
                  const LocationIcon = getLocationIcon(location.type);
                  
                  return (
                    <Card 
                      key={location.id}
                      className="bg-gradient-to-br from-card to-card/50 border-border/50 hover:border-primary/20 transition-all duration-300 cursor-pointer animate-fade-in-up"
                      onClick={() => setSelectedLocation(location)}
                    >
                      <CardHeader>
                        <CardTitle className="flex items-center gap-2 text-lg">
                          <LocationIcon className={`w-5 h-5 ${getLocationColor(location.type)}`} />
                          {location.name}
                        </CardTitle>
                        <CardDescription className="capitalize">
                          {location.type} • {location.powerLevel}
                        </CardDescription>
                      </CardHeader>
                      
                      <CardContent className="space-y-4">
                        <p className="text-sm text-muted-foreground line-clamp-3">
                          {location.description}
                        </p>
                        
                        <div className="space-y-2">
                          <span className="text-xs text-muted-foreground">Current Residents:</span>
                          <div className="flex flex-wrap gap-1">
                            {location.currentCharacters.slice(0, 3).map((character) => (
                              <Badge key={character} variant="outline" className="text-xs">
                                {character}
                              </Badge>
                            ))}
                            {location.currentCharacters.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{location.currentCharacters.length - 3}
                              </Badge>
                            )}
                          </div>
                        </div>

                        <Button 
                          variant="ghost" 
                          size="sm" 
                          className="w-full hover:bg-primary/10"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          Explore Location
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>

      {/* Multiverse Statistics */}
      <div className="max-w-6xl mx-auto">
        <Card className="bg-gradient-to-br from-card to-card/50">
          <CardHeader>
            <CardTitle className="text-2xl text-center">Multiverse Overview</CardTitle>
            <CardDescription className="text-center">
              Statistics across all known universes
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <div className="space-y-2">
                <div className="text-3xl font-bold text-primary">12</div>
                <div className="text-sm text-muted-foreground">Total Universes</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-secondary">47</div>
                <div className="text-sm text-muted-foreground">Known Planets</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-accent">156</div>
                <div className="text-sm text-muted-foreground">Active Characters</div>
              </div>
              <div className="space-y-2">
                <div className="text-3xl font-bold text-ki">∞</div>
                <div className="text-sm text-muted-foreground">Possibilities</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Location Detail Modal */}
      {selectedLocation && (
        <div 
          className="fixed inset-0 bg-background/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedLocation(null)}
        >
          <Card 
            className="bg-gradient-to-br from-card to-card/50 border-primary/20 max-w-3xl w-full max-h-[90vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle className="text-3xl flex items-center gap-3">
                    {(() => {
                      const LocationIcon = getLocationIcon(selectedLocation.type);
                      return <LocationIcon className={`w-7 h-7 ${getLocationColor(selectedLocation.type)}`} />;
                    })()}
                    {selectedLocation.name}
                  </CardTitle>
                  <CardDescription className="text-xl mt-2 capitalize">
                    {selectedLocation.type} • {selectedLocation.powerLevel}
                  </CardDescription>
                </div>
                <Button variant="ghost" size="sm" onClick={() => setSelectedLocation(null)}>
                  ×
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-8">
              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Globe className="w-5 h-5 text-accent" />
                  Description
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {selectedLocation.description}
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Star className="w-5 h-5 text-ki" />
                  Significance
                </h3>
                <p className="text-muted-foreground leading-relaxed p-4 rounded-lg bg-ki/5 border border-ki/20">
                  {selectedLocation.significance}
                </p>
              </div>

              <div>
                <h3 className="text-xl font-semibold mb-4 flex items-center gap-2">
                  <Users className="w-5 h-5 text-secondary" />
                  Current Residents
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                  {selectedLocation.currentCharacters.map((character) => (
                    <div key={character} className="p-3 rounded-lg bg-muted/20 border border-border/50 text-center">
                      <div className="w-8 h-8 bg-gradient-to-br from-primary to-energy rounded-full mx-auto mb-2 flex items-center justify-center">
                        <Users className="w-4 h-4 text-primary-foreground" />
                      </div>
                      <span className="font-medium text-sm">{character}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex justify-center">
                <Button className="bg-gradient-to-r from-primary to-energy">
                  <MapPin className="w-4 h-4 mr-2" />
                  Set Character Location
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
};

export default Worldview;