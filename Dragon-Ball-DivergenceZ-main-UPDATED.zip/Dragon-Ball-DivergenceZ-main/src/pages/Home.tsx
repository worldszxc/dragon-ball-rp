import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { 
  Users, 
  Clock, 
  Globe, 
  FileText, 
  Zap, 
  Star,
  Trophy,
  Swords
} from "lucide-react";

const Home = () => {
  const stats = [
    { label: "Active Characters", value: "47", icon: Users, color: "text-secondary" },
    { label: "Timeline Events", value: "23", icon: Clock, color: "text-accent" },
    { label: "Power Level Record", value: "∞", icon: Zap, color: "text-ki" },
    { label: "Completed Arcs", value: "8", icon: Trophy, color: "text-primary" },
  ];

  const recentActivity = [
    { type: "character", action: "Goku achieved Ultra Instinct", time: "2 hours ago", status: "approved" },
    { type: "timeline", action: "New arc: Galactic Tournament began", time: "1 day ago", status: "active" },
    { type: "submission", action: "New OC: Kairon submitted for review", time: "3 days ago", status: "pending" },
    { type: "battle", action: "Epic battle: Earth vs Universe 6", time: "1 week ago", status: "completed" },
  ];

  return (
    <div className="space-y-8">
      {/* Welcome Section */}
      <div className="text-center space-y-4">
        <div className="animate-fade-in-up">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-primary via-energy to-ki bg-clip-text text-transparent">
            Welcome to the Dragon Ball Universe
          </h1>
          <p className="text-xl text-muted-foreground mt-4 max-w-2xl mx-auto">
            Create legendary characters, explore epic timelines, and shape the destiny of the universe. 
            Your adventure awaits among the stars!
          </p>
        </div>
        
        <div className="flex justify-center gap-4 mt-8">
          <Link to="/submit-oc">
            <Button size="lg" className="bg-gradient-to-r from-primary to-energy text-primary-foreground animate-power-surge">
              <FileText className="w-5 h-5 mr-2" />
              Create Character
            </Button>
          </Link>
          <Link to="/characters">
            <Button size="lg" variant="outline">
              <Users className="w-5 h-5 mr-2" />
              Browse Characters
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={stat.label} className="bg-gradient-to-br from-card to-card/50 border-border/50 hover:border-primary/20 transition-all duration-300 animate-fade-in-up" style={{ animationDelay: `${index * 100}ms` }}>
            <CardContent className="p-6 text-center">
              <div className="flex items-center justify-center mb-3">
                <stat.icon className={`w-8 h-8 ${stat.color}`} />
              </div>
              <div className="text-3xl font-bold text-foreground">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Sections */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Quick Actions */}
        <Card className="bg-gradient-to-br from-card to-card/50 border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Swords className="w-5 h-5 text-primary" />
              Quick Actions
            </CardTitle>
            <CardDescription>Jump into action with these essential features</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Link to="/submit-oc" className="block">
              <div className="p-4 rounded-lg border border-border/50 hover:border-primary/30 hover:bg-muted/30 transition-all cursor-pointer group">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-accent group-hover:text-primary transition-colors" />
                  <div>
                    <h3 className="font-semibold">Submit New Character</h3>
                    <p className="text-sm text-muted-foreground">Create your legendary fighter</p>
                  </div>
                </div>
              </div>
            </Link>
            
            <Link to="/timeline" className="block">
              <div className="p-4 rounded-lg border border-border/50 hover:border-primary/30 hover:bg-muted/30 transition-all cursor-pointer group">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-accent group-hover:text-primary transition-colors" />
                  <div>
                    <h3 className="font-semibold">Explore Timeline</h3>
                    <p className="text-sm text-muted-foreground">Discover epic story arcs</p>
                  </div>
                </div>
              </div>
            </Link>

            <Link to="/worldview" className="block">
              <div className="p-4 rounded-lg border border-border/50 hover:border-primary/30 hover:bg-muted/30 transition-all cursor-pointer group">
                <div className="flex items-center gap-3">
                  <Globe className="w-5 h-5 text-accent group-hover:text-primary transition-colors" />
                  <div>
                    <h3 className="font-semibold">Universe Map</h3>
                    <p className="text-sm text-muted-foreground">Navigate the cosmos</p>
                  </div>
                </div>
              </div>
            </Link>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="bg-gradient-to-br from-card to-card/50 border-border/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-ki" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest updates from across the universe</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div key={index} className="flex items-start gap-3 p-3 rounded-lg bg-muted/20">
                <div className="w-2 h-2 rounded-full bg-primary mt-2" />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-foreground">{activity.action}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                    <Badge 
                      variant={activity.status === 'approved' ? 'default' : activity.status === 'pending' ? 'secondary' : 'outline'}
                      className="text-xs"
                    >
                      {activity.status}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Featured Content */}
      <Card className="bg-gradient-to-r from-primary/10 via-energy/5 to-ki/10 border-primary/20">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl">Current Arc: Tournament of Power</CardTitle>
          <CardDescription className="text-base">
            The ultimate battle between universes has begun. Only the strongest will survive!
          </CardDescription>
        </CardHeader>
        <CardContent className="text-center">
          <div className="flex justify-center gap-4">
            <Link to="/timeline">
              <Button variant="outline" className="border-primary/30 hover:bg-primary/10">
                View Arc Details
              </Button>
            </Link>
            <Link to="/characters">
              <Button className="bg-gradient-to-r from-primary to-energy">
                See Participants
              </Button>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Home;