import { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';

export function useAdmin() {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) {
      setIsAdmin(false);
      setLoading(false);
      return;
    }

    // Check if user is admin by email
    setIsAdmin(user.email === 'patheticworlds@gmail.com');
    setLoading(false);
  }, [user]);

  return { isAdmin, loading };
}