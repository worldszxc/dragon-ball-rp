import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Plus, Trash2, Send, Loader2, Zap, Users } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { useToast } from '@/hooks/use-toast';

interface LocalTechnique {
  name: string;
  description: string;
  type: string;
}

interface LocalAbility {
  name: string;
  description: string;
}

const dragonBallRaces = [
  "Saiyan", "Human", "Namekian", "Majin", "Android/Cyborg", 
  "Frieza Race", "Kai", "Angel", "Tuffle", "Saiyan-Human Hybrid",
  "Demon", "Bio-Android", "Custom"
];

const techniqueTypes = [
  "Energy Blast", "Physical Technique", "Transformation", 
  "Healing", "Support", "Ultimate Attack", "Special Ability"
];

const OcSubmissionForm = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    race: "",
    customRace: "",
    powerLevel: 1000,
    personality: "",
    backstory: "",
    extraNotes: "",
    appearance: "",
    alignment: "",
    currentLocation: ""
  });

  const [techniques, setTechniques] = useState<LocalTechnique[]>([]);
  const [abilities, setAbilities] = useState<LocalAbility[]>([]);
  const [newTechnique, setNewTechnique] = useState({ name: "", description: "", type: "" });
  const [newAbility, setNewAbility] = useState({ name: "", description: "" });

  const addTechnique = () => {
    if (newTechnique.name && newTechnique.description && newTechnique.type) {
      setTechniques([...techniques, newTechnique]);
      setNewTechnique({ name: "", description: "", type: "" });
    }
  };

  const removeTechnique = (index: number) => {
    setTechniques(techniques.filter((_, i) => i !== index));
  };

  const addAbility = () => {
    if (newAbility.name && newAbility.description) {
      setAbilities([...abilities, newAbility]);
      setNewAbility({ name: "", description: "" });
    }
  };

  const removeAbility = (index: number) => {
    setAbilities(abilities.filter((_, i) => i !== index));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!user) {
      toast({
        title: "Authentication Required",
        description: "You must be logged in to submit a character",
        variant: "destructive"
      });
      return;
    }

    if (!formData.name || !formData.race || !formData.alignment) {
      toast({
        title: "Missing Required Fields",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    setIsSubmitting(true);

    try {
      // Insert character
      const { data: character, error: characterError } = await supabase
        .from('characters')
        .insert({
          user_id: user.id,
          name: formData.name,
          race: formData.race === 'Custom' ? formData.customRace : formData.race,
          power_level: formData.powerLevel,
          alignment: formData.alignment,
          creator: user.email || 'Anonymous',
          current_location: formData.currentLocation,
          personality: formData.personality,
          backstory: formData.backstory,
          appearance: formData.appearance,
          extra_notes: formData.extraNotes,
          approved: false
        })
        .select()
        .single();

      if (characterError) throw characterError;

      // Insert techniques
      if (techniques.length > 0) {
        const techniquesData = techniques.map(tech => ({
          character_id: character.id,
          name: tech.name,
          description: tech.description,
          type: tech.type
        }));

        const { error: techniquesError } = await supabase
          .from('techniques')
          .insert(techniquesData);

        if (techniquesError) throw techniquesError;
      }

      // Insert abilities
      if (abilities.length > 0) {
        const abilitiesData = abilities.map(ability => ({
          character_id: character.id,
          name: ability.name,
          description: ability.description
        }));

        const { error: abilitiesError } = await supabase
          .from('abilities')
          .insert(abilitiesData);

        if (abilitiesError) throw abilitiesError;
      }

      toast({
        title: "Character Submitted!",
        description: "Your character has been submitted for approval and will appear in the database once reviewed.",
      });

      // Reset form
      setFormData({
        name: "",
        age: "",
        race: "",
        customRace: "",
        powerLevel: 1000,
        personality: "",
        backstory: "",
        extraNotes: "",
        appearance: "",
        alignment: "",
        currentLocation: ""
      });
      setTechniques([]);
      setAbilities([]);

    } catch (error) {
      console.error('Error submitting character:', error);
      toast({
        title: "Submission Failed",
        description: "There was an error submitting your character. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold bg-gradient-to-r from-primary to-energy bg-clip-text text-transparent">
          Create Your Legendary Character
        </h1>
        <p className="text-muted-foreground">
          Forge a new warrior destined for greatness in the Dragon Ball universe
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Basic Information */}
        <Card className="bg-gradient-to-br from-card to-card/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-primary" />
              Basic Information
            </CardTitle>
            <CardDescription>Essential details about your character</CardDescription>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Character Name *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="Enter character name"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="age">Age</Label>
              <Input
                id="age"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                placeholder="Character's age"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="race">Race *</Label>
              <Select
                value={formData.race}
                onValueChange={(value) => setFormData({ ...formData, race: value })}
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select race" />
                </SelectTrigger>
                <SelectContent>
                  {dragonBallRaces.map((race) => (
                    <SelectItem key={race} value={race}>{race}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {formData.race === "Custom" && (
              <div className="space-y-2">
                <Label htmlFor="customRace">Custom Race Details *</Label>
                <Input
                  id="customRace"
                  value={formData.customRace}
                  onChange={(e) => setFormData({ ...formData, customRace: e.target.value })}
                  placeholder="Describe your custom race"
                  required
                />
              </div>
            )}

            <div className="space-y-2">
              <Label htmlFor="powerLevel">Power Level</Label>
              <Input
                id="powerLevel"
                type="number"
                value={formData.powerLevel}
                onChange={(e) => setFormData({ ...formData, powerLevel: parseInt(e.target.value) || 1000 })}
                placeholder="Current power level"
                min="1000"
                max="999999999"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="currentLocation">Current Location</Label>
              <Input
                id="currentLocation"
                value={formData.currentLocation}
                onChange={(e) => setFormData({ ...formData, currentLocation: e.target.value })}
                placeholder="Where is your character now?"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="alignment">Alignment</Label>
              <Select
                value={formData.alignment}
                onValueChange={(value) => setFormData({ ...formData, alignment: value })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Character alignment" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Hero">Hero</SelectItem>
                  <SelectItem value="Villain">Villain</SelectItem>
                  <SelectItem value="Neutral">Neutral</SelectItem>
                  <SelectItem value="Anti-Hero">Anti-Hero</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>

        {/* Techniques */}
        <Card className="bg-gradient-to-br from-card to-card/50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Zap className="w-5 h-5 text-energy" />
              Techniques & Abilities
            </CardTitle>
            <CardDescription>Special moves and powers your character possesses</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Add New Technique */}
            <div className="p-4 border border-border/50 rounded-lg bg-muted/20">
              <h4 className="font-semibold mb-4">Add Technique</h4>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Input
                  placeholder="Technique name"
                  value={newTechnique.name}
                  onChange={(e) => setNewTechnique({ ...newTechnique, name: e.target.value })}
                />
                <Select
                  value={newTechnique.type}
                  onValueChange={(value) => setNewTechnique({ ...newTechnique, type: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    {techniqueTypes.map((type) => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button type="button" onClick={addTechnique} size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>
              <Textarea
                className="mt-4"
                placeholder="Describe how the technique works..."
                value={newTechnique.description}
                onChange={(e) => setNewTechnique({ ...newTechnique, description: e.target.value })}
              />
            </div>

            {/* Techniques List */}
            {techniques.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold">Character Techniques</h4>
                {techniques.map((technique, index) => (
                  <div key={index} className="flex items-start justify-between p-3 bg-muted/30 rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="font-medium">{technique.name}</span>
                        <Badge variant="outline">{technique.type}</Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{technique.description}</p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeTechnique(index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}

            <Separator />

            {/* Add New Ability */}
            <div className="p-4 border border-border/50 rounded-lg bg-muted/20">
              <h4 className="font-semibold mb-4">Add Special Ability</h4>
              <div className="flex gap-4">
                <Input
                  placeholder="Ability name"
                  value={newAbility.name}
                  onChange={(e) => setNewAbility({ ...newAbility, name: e.target.value })}
                  className="flex-1"
                />
                <Button type="button" onClick={addAbility} size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>
              <Textarea
                className="mt-4"
                placeholder="Describe the special ability..."
                value={newAbility.description}
                onChange={(e) => setNewAbility({ ...newAbility, description: e.target.value })}
              />
            </div>

            {/* Abilities List */}
            {abilities.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold">Special Abilities</h4>
                {abilities.map((ability, index) => (
                  <div key={index} className="flex items-start justify-between p-3 bg-muted/30 rounded-lg">
                    <div className="flex-1">
                      <span className="font-medium">{ability.name}</span>
                      <p className="text-sm text-muted-foreground mt-1">{ability.description}</p>
                    </div>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => removeAbility(index)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Character Details */}
        <Card className="bg-gradient-to-br from-card to-card/50">
          <CardHeader>
            <CardTitle>Character Details</CardTitle>
            <CardDescription>Personality, backstory, and additional information</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="personality">Personality *</Label>
              <Textarea
                id="personality"
                value={formData.personality}
                onChange={(e) => setFormData({ ...formData, personality: e.target.value })}
                placeholder="Describe your character's personality, traits, and behavior..."
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="backstory">Backstory *</Label>
              <Textarea
                id="backstory"
                value={formData.backstory}
                onChange={(e) => setFormData({ ...formData, backstory: e.target.value })}
                placeholder="Tell us your character's origin story and background..."
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="appearance">Physical Appearance</Label>
              <Textarea
                id="appearance"
                value={formData.appearance}
                onChange={(e) => setFormData({ ...formData, appearance: e.target.value })}
                placeholder="Describe how your character looks..."
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="extraNotes">Extra Notes</Label>
              <Textarea
                id="extraNotes"
                value={formData.extraNotes}
                onChange={(e) => setFormData({ ...formData, extraNotes: e.target.value })}
                placeholder="Any additional information about your character..."
              />
            </div>
          </CardContent>
        </Card>

        {/* Submit Button */}
        <div className="flex justify-end">
          <Button 
            type="submit" 
            size="lg" 
            className="bg-gradient-primary hover:opacity-90 transition-opacity"
            disabled={isSubmitting}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Submitting Character...
              </>
            ) : (
              <>
                <Send className="mr-2 h-4 w-4" />
                Submit Character for Review
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
};

export default OcSubmissionForm;