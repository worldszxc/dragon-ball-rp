import { useState } from "react";
import { NavLink, Navigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Zap, 
  Users, 
  Clock, 
  Globe, 
  Shield, 
  FileText, 
  Settings,
  Crown,
  LogOut
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import heroImage from "@/assets/hero-bg.jpg";

interface LayoutProps {
  isAdmin: boolean;
  children: React.ReactNode;
}

const Layout = ({ isAdmin, children }: LayoutProps) => {
  const { user, loading, signOut } = useAuth();
  const [currentArc] = useState("Tournament of Power");

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  const handleSignOut = async () => {
    await signOut();
  };

  const navItems = [
    { path: "/", icon: Zap, label: "Home", public: true },
    { path: "/characters", icon: Users, label: "Characters", public: true },
    { path: "/timeline", icon: Clock, label: "Timeline", public: true },
    { path: "/worldview", icon: Globe, label: "Worldview", public: true },
    { path: "/submit-oc", icon: FileText, label: "Submit OC", public: true },
    { path: "/admin", icon: Shield, label: "Admin Panel", public: false },
    { path: "/admin/settings", icon: Settings, label: "Settings", public: false },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Hero Header */}
      <header className="relative overflow-hidden border-b border-border">
        <div 
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: `url(${heroImage})` }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-transparent" />
        
        <div className="relative max-w-7xl mx-auto px-6 py-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 bg-gradient-to-br from-primary to-energy rounded-full flex items-center justify-center animate-ki-pulse">
                  <Zap className="w-6 h-6 text-primary-foreground" />
                </div>
                <div>
                  <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-energy bg-clip-text text-transparent">
                    Dragon Ball RPG Hub
                  </h1>
                  <p className="text-sm text-muted-foreground">
                    Current Arc: <span className="text-ki font-semibold">{currentArc}</span>
                  </p>
                </div>
              </div>
            </div>
            
            {isAdmin && (
              <Badge variant="secondary" className="gap-2 bg-gradient-to-r from-primary/20 to-energy/20 border-primary/30">
                <Crown className="w-4 h-4" />
                Administrator
              </Badge>
            )}
            
            <div className="flex items-center gap-4">
              <span className="text-sm text-muted-foreground">
                Welcome, {user.email}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={handleSignOut}
                className="flex items-center gap-2"
              >
                <LogOut className="h-4 w-4" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex items-center gap-2 py-4 overflow-x-auto">
            {navItems
              .filter(item => item.public || isAdmin)
              .map((item) => (
                <NavLink key={item.path} to={item.path}>
                  {({ isActive }) => (
                    <Button
                      variant={isActive ? "default" : "ghost"}
                      size="sm"
                      className={`flex items-center gap-2 whitespace-nowrap ${
                        isActive 
                          ? "bg-gradient-to-r from-primary to-energy text-primary-foreground shadow-lg" 
                          : "hover:bg-muted"
                      }`}
                    >
                      <item.icon className="w-4 h-4" />
                      {item.label}
                    </Button>
                  )}
                </NavLink>
              ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-border bg-card/30 mt-16">
        <div className="max-w-7xl mx-auto px-6 py-6 text-center">
          <p className="text-sm text-muted-foreground">
            Dragon Ball RPG Hub - Power levels over 9000! 🐉
          </p>
        </div>
      </footer>
    </div>
  );
};

export default Layout;